package com.pendulum.ui.fragment;///*
// *
// *  Proprietary and confidential. Property of Kellton Tech Solutions Ltd. Do not disclose or distribute.
// *  You must have written permission from Kellton Tech Solutions Ltd. to use this code.
// *
// */
//
//package com.com.taxi.ui.fragment;
//
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentActivity;
//
//import com.com.taxi.ui.IScreen;
//import com.com.taxi.ui.activity.BaseActivity;
//
///**
// * @author sachn.guta
// */
//public abstract class BaseFragment extends Fragment implements IScreen {
//
//    /**
//     * @return
//     */
//    protected BaseActivity getBaseActivity() {
//        FragmentActivity activity = getActivity();
//        if (!(activity instanceof BaseActivity) || activity.isFinishing()) {
//            return null;
//        }
//        return (BaseActivity) activity;
//    }
//}
