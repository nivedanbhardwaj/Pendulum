package com.pend;

import java.io.Serializable;

public class BaseResponseModel implements Serializable {
    public boolean status;
    public String statusCode;

}
