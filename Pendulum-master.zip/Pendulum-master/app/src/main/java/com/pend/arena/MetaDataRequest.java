package com.pend.arena;

/**
 * Created by chaudhary on 3/17/2018.
 */

public class MetaDataRequest {
}
