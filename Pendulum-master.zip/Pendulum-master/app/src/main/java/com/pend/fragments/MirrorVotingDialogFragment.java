package com.pend.fragments;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.RadioGroup;

import com.google.gson.JsonObject;
import com.pend.BaseActivity;
import com.pend.R;
import com.pend.interfaces.IApiEvent;
import com.pend.interfaces.IMirrorVotingDialogCallBack;
import com.pend.interfaces.IWebServices;
import com.pend.models.MirrorVoteResponseModel;
import com.pend.util.LoggerUtil;
import com.pend.util.NetworkUtil;
import com.pend.util.RequestPostDataUtil;
import com.pend.util.SharedPrefUtils;
import com.pend.util.VolleyErrorListener;
import com.pendulum.ui.IScreen;
import com.pendulum.utils.ConnectivityUtils;
import com.pendulum.volley.ext.GsonObjectRequest;
import com.pendulum.volley.ext.RequestManager;

public class MirrorVotingDialogFragment extends DialogFragment implements IScreen, View.OnClickListener {

    private static final String TAG = MirrorVotingDialogFragment.class.getSimpleName();
    private static final String ARG_MIRROR_ID = "ARG_MIRROR_ID";
    private IMirrorVotingDialogCallBack mIMirrorVotingDialogCallBack;

    private RadioGroup mRgVote;
    private BaseActivity mContext;
    private int mMirrorId;
    private boolean mIsAdmire;
    private boolean mIsHate;
    private boolean mIsCanTSay;

    public static MirrorVotingDialogFragment newInstance(int mirrorId) {
        MirrorVotingDialogFragment fragment = new MirrorVotingDialogFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_MIRROR_ID, mirrorId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mMirrorId = getArguments().getInt(ARG_MIRROR_ID, 0);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = (BaseActivity) context;
        mIMirrorVotingDialogCallBack = (IMirrorVotingDialogCallBack) context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_voting_popup, container, false);
        if (getDialog().getWindow() != null) {
            getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        }

        initUI(view);
        setInitialData();
        return view;
    }

    private void initUI(View view) {

        mRgVote = view.findViewById(R.id.rg_vote);
        view.findViewById(R.id.bt_okay).setOnClickListener(this);
        view.findViewById(R.id.bt_cancel).setOnClickListener(this);
    }

    private void setInitialData() {

    }

    @Override
    public void updateUi(boolean status, int actionID, Object serviceResponse) {
        switch (actionID) {
            case IApiEvent.REQUEST_MIRROR_VOTE_CODE:
                if (status) {
                    MirrorVoteResponseModel mirrorVoteResponseModel = (MirrorVoteResponseModel) serviceResponse;
                    if (mirrorVoteResponseModel != null && mirrorVoteResponseModel.status) {
                        LoggerUtil.d(TAG, mirrorVoteResponseModel.statusCode);

                        if (mirrorVoteResponseModel.Data != null && mirrorVoteResponseModel.Data.voteData != null) {
                            mIMirrorVotingDialogCallBack.onVotingOrUnVotingClick();
                        }
                    } else {
                        LoggerUtil.d(TAG, getString(R.string.server_error_from_api));
                    }
                } else {
                    LoggerUtil.d(TAG, getString(R.string.status_is_false));
                }
                this.dismiss();
                break;

            default:
                LoggerUtil.d(TAG, getString(R.string.wrong_case_selection));
                break;
        }
        if (mContext != null && !mContext.isDestroyed() && !mContext.isFinishing() && isAdded()) {

            mContext.removeProgressDialog();
        }
    }

    @Override
    public void onEvent(int eventId, Object eventData) {

    }

    @Override
    public void getData(final int actionID) {

        if (mContext != null && !mContext.isDestroyed() && !mContext.isFinishing() && isAdded()) {

            if (!ConnectivityUtils.isNetworkEnabled(mContext)) {
//            Snackbar.make(mRootView, getString(R.string.no_internet_connection), Snackbar.LENGTH_LONG).show();
                return;
            }
            mContext.showProgressDialog();
        } else {
            return;
        }

        int userId = -1;
        try {
            userId = Integer.parseInt(SharedPrefUtils.getUserId(mContext));
        } catch (Exception e) {
            e.printStackTrace();
        }

        switch (actionID) {
            case IApiEvent.REQUEST_MIRROR_VOTE_CODE:

                JsonObject requestObject = RequestPostDataUtil.mirrorVoteApiRegParam(userId, mMirrorId, mIsAdmire, mIsHate, mIsCanTSay);
                String request = requestObject.toString();
                RequestManager.addRequest(new GsonObjectRequest<MirrorVoteResponseModel>(IWebServices.REQUEST_MIRROR_VOTE_URL,
                        NetworkUtil.getHeaders(mContext), request, MirrorVoteResponseModel.class, new VolleyErrorListener(this, actionID)) {

                    @Override
                    protected void deliverResponse(MirrorVoteResponseModel response) {
                        updateUi(true, actionID, response);
                    }
                });
                break;

            default:
                LoggerUtil.d(TAG, getString(R.string.wrong_case_selection));
                break;
        }
    }

    @Override
    public void onAuthError() {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_okay:

                if (!(mRgVote.getCheckedRadioButtonId() == -1)) {
                    switch (mRgVote.getCheckedRadioButtonId()) {
                        case R.id.rb_admire:
                            mIsAdmire = true;
                            mIsHate = false;
                            mIsCanTSay = false;
                            break;

                        case R.id.rb_hate:
                            mIsAdmire = false;
                            mIsHate = true;
                            mIsCanTSay = false;
                            break;

                        case R.id.rb_can_t_say:
                            mIsAdmire = false;
                            mIsHate = false;
                            mIsCanTSay = true;
                            break;
                    }
                    getData(IApiEvent.REQUEST_MIRROR_VOTE_CODE);
                }
                break;

            case R.id.bt_cancel:
                this.dismiss();
                break;

            default:
                LoggerUtil.d(TAG, getString(R.string.wrong_case_selection));
                break;
        }
    }
}
