package com.pend.interfaces;

public interface IContestVotingCallBack {
    void onVotingOrUnVotingClick();
}
