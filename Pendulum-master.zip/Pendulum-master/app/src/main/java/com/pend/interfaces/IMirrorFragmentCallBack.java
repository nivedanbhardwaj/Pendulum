package com.pend.interfaces;

public interface IMirrorFragmentCallBack {
    void onCreateMirrorClick();
}
