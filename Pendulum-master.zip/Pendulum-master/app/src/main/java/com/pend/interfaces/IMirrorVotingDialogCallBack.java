package com.pend.interfaces;

public interface IMirrorVotingDialogCallBack {
    void onVotingOrUnVotingClick();
}
