package com.pend.models;

import java.io.Serializable;

public class ErrorExceptionModel implements Serializable {
    public String Message;
}
