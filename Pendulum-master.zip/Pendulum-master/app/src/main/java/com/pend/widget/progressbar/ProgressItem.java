package com.pend.widget.progressbar;

public class ProgressItem {
	public int color;
	public float progressItemPercentage;

	public ProgressItem(int color, float progressItemPercentage) {
		this.color = color;
		this.progressItemPercentage = progressItemPercentage;
	}
}
